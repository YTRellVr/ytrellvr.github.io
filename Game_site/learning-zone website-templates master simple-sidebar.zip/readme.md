## Project Description

* [live example](https://learning-zone.github.io/website-templates/simple-sidebar)

![alt text](https://github.com/learning-zone/website-templates/blob/master/assets/simple-sidebar.png "simple-sidebar")
